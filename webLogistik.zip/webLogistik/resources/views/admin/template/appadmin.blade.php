@include('admin.template.header')

<div>
    <div class="container-fluid px-4">
        @yield('content')
    </div>
</div>

@include('admin.template.footer')