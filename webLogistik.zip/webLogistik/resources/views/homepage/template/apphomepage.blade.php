@include('homepage.template.header')


<div>
    <div class="container-fluid px-4">
        @yield('content')
    </div>
</div>

@include('homepage.template.footer')