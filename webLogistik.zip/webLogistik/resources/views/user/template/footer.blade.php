<footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>Logistik</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="{{asset('user/vendor/apexcharts/apexcharts.min.js')}}"></script>
  <script src="{{asset('user/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
  <script src="{{asset('user/vendor/chart.js/chart.umd.js')}}"></script>
  <script src="{{asset('user/vendor/echarts/echarts.min.js')}}"></script>
  <script src="{{asset('user/vendor/quill/quill.min.js')}}"></script>
  <script src="{{asset('user/vendor/simple-datatables/simple-datatables.js')}}"></script>
  <script src="{{asset('user/vendor/tinymce/tinymce.min.js')}}"></script>
  <script src="{{asset('user/vendor/php-email-form/validate.js')}}"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

  <!-- Template Main JS File -->
  <script src="{{asset('user/js/main.js')}}"></script>

</body>

</html>