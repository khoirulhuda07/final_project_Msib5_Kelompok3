@include('user.template.header')

<div>
    <div class="container-fluid px-4">
        @yield('content')
    </div>
</div>
</div>

@include('user.template.footer')